# Masjid Website

This repository contains a single-file static website: `index.html`.

## Quick Deploy to GitHub Pages

### Option A — User site (recommended)
1. Create a new repository named **`<your-username>.github.io`** (replace with your GitHub username).
2. Upload `index.html` to the root of the repository.
3. Commit.
4. Go to **Settings → Pages**.
   - **Source:** *Deploy from a branch*
   - **Branch:** `main` and `/ (root)` → **Save**
5. After the green **Pages** build finishes (check the **Actions** tab), your site will be live at:
   `https://<your-username>.github.io`

### Option B — Project site
1. Create any repo name (e.g., `masjid-site`).
2. Upload `index.html` to the root of the repository.
3. Go to **Settings → Pages**.
   - **Source:** *Deploy from a branch*
   - **Branch:** `main` and `/ (root)` → **Save**
4. Your site will be live at:
   `https://<your-username>.github.io/<repo-name>/`

## Common Fixes
- Ensure the file name is exactly **`index.html`** (lowercase).
- Put `index.html` in the **root**, not in a folder.
- Case-sensitive URLs: `Index.html` ≠ `index.html`.
- Check **Actions** → **Pages build and deployment** for errors.
- In **Settings → Pages**, make sure a branch and `/ (root)` are selected.
- Turn on **Enforce HTTPS** in **Settings → Pages** after your first deploy.

## Editing the Site
- Open `index.html` on GitHub → **Edit** → make changes (e.g., prayer/iqamah times) → **Commit changes**.
- Refresh the site after the Page re-deploys.
